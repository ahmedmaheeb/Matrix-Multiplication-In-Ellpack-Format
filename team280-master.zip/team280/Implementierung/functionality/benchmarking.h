//
// Created by abdelgha on 7/15/22.
//

#ifndef PROJEKTAUFGABE_BENCHMARKING_H
#define PROJEKTAUFGABE_BENCHMARKING_H
#include "ellpack_utility.h"

void benchmark(int version, int iterations, struct EllpackMatrix * a, struct EllpackMatrix * b, struct EllpackMatrix *res);

#endif //PROJEKTAUFGABE_BENCHMARKING_H
